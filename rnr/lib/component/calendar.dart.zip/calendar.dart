import 'package:flutter/material.dart';
import 'package:date_utils/date_utils.dart';

class CalendarWidget extends StatefulWidget {
  CalendarWidget({
    this.height = 256,
    this.backgroundColor = Colors.black,
  });

  final double height;
  final Color backgroundColor;

  @override
  _CalendarWidgetState createState() => _CalendarWidgetState();
}

class _CalendarWidgetState extends State<CalendarWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
        //height: widget.height,
        color: widget.backgroundColor,
        child: Column(
          children: <Widget>[
            _CalendarHeader(
              title: '二月',
            ),
            _CalendarWeekHeader(),
            _CalendarDaysBody(),
          ],
        ));
  }
}

//CalenderHeader
class _CalendarHeader extends StatelessWidget {
  _CalendarHeader({
    @required this.title,
    this.textStyle,
    this.iconColor = Colors.white,
    this.leftCallback,
    this.rightCallback,
  });

  final String title;
  final TextStyle textStyle;
  final Color iconColor;
  final VoidCallback leftCallback;
  final VoidCallback rightCallback;

  TextStyle _getTextStyle() {
    return textStyle != null
        ? textStyle
        : TextStyle(
            fontSize: 20,
            color: Colors.white,
          );
  }

  Widget _leftButton() => IconButton(
        onPressed: leftCallback,
        icon: Icon(Icons.chevron_left, color: iconColor),
      );

  Widget _rightButton() => IconButton(
        onPressed: rightCallback,
        icon: Icon(Icons.chevron_right, color: iconColor),
      );

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 1, horizontal: 5),
      child: DefaultTextStyle(
        style: _getTextStyle(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            _leftButton(),
            Text(
              title,
              style: _getTextStyle(),
            ),
            _rightButton(),
          ],
        ),
      ),
    );
  }
}

//CalenderHeader
class _CalendarWeekHeader extends StatelessWidget {
  _CalendarWeekHeader({
    this.textStyle,
  });
  final TextStyle textStyle;

  TextStyle _getTextStyle() {
    return textStyle != null
        ? textStyle
        : TextStyle(
            fontSize: 10,
            color: Colors.white,
          );
  }

  

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20, vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Text(
            '日',
            style: _getTextStyle(),
          ),
          Text(
            '一',
            style: _getTextStyle(),
          ),
          Text(
            '二',
            style: _getTextStyle(),
          ),
          Text(
            '三',
            style: _getTextStyle(),
          ),
          Text(
            '四',
            style: _getTextStyle(),
          ),
          Text(
            '五',
            style: _getTextStyle(),
          ),
          Text(
            '六',
            style: _getTextStyle(),
          ),
        ],
      ),
    );
  }
}

//CalenderHeader
class _CalendarDaysBody extends StatelessWidget {
  _CalendarDaysBody({
    this.textStyle,
    this.onPressedCallback,
    this.time,
  });
  final TextStyle textStyle;
  final VoidCallback onPressedCallback;
  final DateTime time;

  

  TextStyle _getTextStyle() {
    return textStyle != null
        ? textStyle
        : TextStyle(
            fontSize: 10,
            color: Colors.white,
          );
  }

  void onPressed(index) {
    if (onPressedCallback != null) onPressedCallback();
  }

  List<DateTime> _days() {
    var day = this.time != null ? time :DateTime.now();
    return Utils.daysInMonth(day);
  }

  @override
  Widget build(BuildContext context) {
    var days =_days();
    var count =days.length;


    return Expanded(
      child: GridView.count(
        crossAxisCount: 7,
        childAspectRatio: 2,
        shrinkWrap :true,
        
        children: List.generate(count, (index) {
          var indexDay = days[index];
          var title = indexDay.day.toString();
          var specialDayOfThisMonth = days[7];
          bool dayOfThisMonth = indexDay.month ==specialDayOfThisMonth.month;
          var color =dayOfThisMonth ? Colors.black : Colors.black12;

          return Container(
            padding: EdgeInsets.symmetric(vertical: 2),
            child: FlatButton(
              onPressed: () {
                onPressed(index);
              },
              color: Colors.green,
              shape: CircleBorder(
                  side: BorderSide(
                color: Colors.green,
              )),
              child: Text(title,style: TextStyle(
                fontSize: 15,
                color: color,
              ),),
            ),
          );
        }),
      ),
    );
  }
}
